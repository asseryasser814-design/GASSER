import os, sqlite3, secrets
from pathlib import Path
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "profile.db"
UPLOAD_DIR = ROOT / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or secrets.token_hex(32)
ADMIN_PATH = os.environ.get("ADMIN_PATH", "gasser-control-7x9").strip("/")
if not ADMIN_PATH or "/" in ADMIN_PATH:
    raise RuntimeError("ADMIN_PATH must be one URL segment, for example gasser-control-7x9")
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}

DEFAULTS = {
    "name": "GASSER", "nickname": "", "age": "", "job": "", "country": "",
    "bio": "أهلاً بيك في صفحتي الشخصية.", "background": "uploads/background.jpg",
    "profile_image": "", "accent": "#a855f7"
}

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        con.execute("CREATE TABLE IF NOT EXISTS socials (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, url TEXT NOT NULL, emoji TEXT DEFAULT '🔗', sort_order INTEGER DEFAULT 0)")
        con.execute("CREATE TABLE IF NOT EXISTS admin (id INTEGER PRIMARY KEY CHECK(id=1), password_hash TEXT NOT NULL)")
        for k, v in DEFAULTS.items():
            con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

init_db()

def get_settings():
    with db() as con:
        rows = con.execute("SELECT key,value FROM settings").fetchall()
    data = dict(DEFAULTS)
    data.update({r["key"]: r["value"] for r in rows})
    return data

def save_setting(key, value):
    with db() as con:
        con.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

def admin_exists():
    with db() as con:
        return con.execute("SELECT 1 FROM admin WHERE id=1").fetchone() is not None

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

def allowed_file(name):
    return "." in name and name.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.get("/")
def home():
    with db() as con:
        socials = con.execute("SELECT * FROM socials ORDER BY sort_order,id").fetchall()
    return render_template("home.html", p=get_settings(), socials=socials)

@app.get("/" + ADMIN_PATH + "/setup")
def admin_setup():
    if admin_exists():
        return redirect(url_for("admin_login"))
    return render_template("setup.html", panel=ADMIN_PATH)

@app.post("/" + ADMIN_PATH + "/setup")
def admin_setup_post():
    if admin_exists():
        abort(404)
    password = request.form.get("password", "")
    confirm = request.form.get("confirm", "")
    if len(password) < 10:
        flash("كلمة المرور لازم تكون 10 أحرف على الأقل.", "error")
    elif password != confirm:
        flash("كلمتا المرور غير متطابقتين.", "error")
    else:
        with db() as con:
            con.execute("INSERT INTO admin(id,password_hash) VALUES(1,?)", (generate_password_hash(password),))
        session["admin"] = True
        return redirect(url_for("admin_dashboard"))
    return redirect(url_for("admin_setup"))

@app.route("/" + ADMIN_PATH, methods=["GET", "POST"])
def admin_login():
    if not admin_exists():
        return redirect(url_for("admin_setup"))
    if session.get("admin"):
        return redirect(url_for("admin_dashboard"))
    if request.method == "POST":
        password = request.form.get("password", "")
        with db() as con:
            row = con.execute("SELECT password_hash FROM admin WHERE id=1").fetchone()
        if row and check_password_hash(row["password_hash"], password):
            session.clear()
            session["admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("كلمة المرور غير صحيحة.", "error")
    return render_template("login.html", panel=ADMIN_PATH)

@app.get("/" + ADMIN_PATH + "/dashboard")
@login_required
def admin_dashboard():
    with db() as con:
        socials = con.execute("SELECT * FROM socials ORDER BY sort_order,id").fetchall()
    return render_template("dashboard.html", p=get_settings(), socials=socials, panel=ADMIN_PATH)

@app.post("/" + ADMIN_PATH + "/save-profile")
@login_required
def save_profile():
    for key in ("name","nickname","age","job","country","bio","accent"):
        save_setting(key, request.form.get(key, "").strip())
    flash("تم حفظ معلوماتك.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/" + ADMIN_PATH + "/upload-background")
@login_required
def upload_background():
    f = request.files.get("background")
    if not f or not f.filename or not allowed_file(f.filename):
        flash("اختر صورة بصيغة PNG أو JPG أو WEBP أو GIF.", "error")
        return redirect(url_for("admin_dashboard"))
    ext = f.filename.rsplit(".", 1)[1].lower()
    name = "background-" + secrets.token_hex(6) + "." + ext
    f.save(UPLOAD_DIR / name)
    save_setting("background", "uploads/" + name)
    flash("تم تغيير الخلفية.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/" + ADMIN_PATH + "/upload-avatar")
@login_required
def upload_avatar():
    f = request.files.get("avatar")
    if not f or not f.filename or not allowed_file(f.filename):
        flash("اختر صورة صالحة.", "error")
        return redirect(url_for("admin_dashboard"))
    ext = f.filename.rsplit(".", 1)[1].lower()
    name = "avatar-" + secrets.token_hex(6) + "." + ext
    f.save(UPLOAD_DIR / name)
    save_setting("profile_image", "uploads/" + name)
    flash("تم تحديث الصورة الشخصية.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/" + ADMIN_PATH + "/social/add")
@login_required
def social_add():
    label = request.form.get("label", "").strip()
    url = request.form.get("url", "").strip()
    emoji = request.form.get("emoji", "🔗").strip() or "🔗"
    if not label or not url or not (url.startswith("https://") or url.startswith("http://")):
        flash("اكتب اسم الرابط ورابطًا يبدأ بـ https://", "error")
    else:
        with db() as con:
            con.execute("INSERT INTO socials(label,url,emoji) VALUES(?,?,?)", (label, url, emoji))
        flash("تمت إضافة الرابط.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/" + ADMIN_PATH + "/social/delete/<int:social_id>")
@login_required
def social_delete(social_id):
    with db() as con:
        con.execute("DELETE FROM socials WHERE id=?", (social_id,))
    flash("تم حذف الرابط.", "success")
    return redirect(url_for("admin_dashboard"))

@app.post("/" + ADMIN_PATH + "/change-password")
@login_required
def change_password():
    old = request.form.get("old_password", "")
    new = request.form.get("new_password", "")
    confirm = request.form.get("confirm_password", "")
    with db() as con:
        row = con.execute("SELECT password_hash FROM admin WHERE id=1").fetchone()
        if not row or not check_password_hash(row["password_hash"], old):
            flash("كلمة المرور الحالية غير صحيحة.", "error")
        elif len(new) < 10:
            flash("كلمة المرور الجديدة لازم تكون 10 أحرف على الأقل.", "error")
        elif new != confirm:
            flash("تأكيد كلمة المرور غير مطابق.", "error")
        else:
            con.execute("UPDATE admin SET password_hash=? WHERE id=1", (generate_password_hash(new),))
            flash("تم تغيير كلمة المرور بنجاح.", "success")
    return redirect(url_for("admin_dashboard"))

@app.get("/" + ADMIN_PATH + "/logout")
@login_required
def admin_logout():
    session.clear()
    return redirect(url_for("admin_login"))

@app.errorhandler(413)
def too_large(_):
    return "حجم الصورة أكبر من 8 ميجابايت.", 413

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
